﻿#include <iostream>
#include <string>
#include <graphics.h>
#include <easyx.h>
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::wcout;
#define Elemtype wchar_t
#define MaxSize 100
typedef struct Node
{
    Elemtype data;      //结点的值
    int weight;         //结点的权值
    Node* LeftChild;    //结点的左孩子
    Node* RightChild;   //结点的右孩子
}Node, * Nodes;

class Huffman
{
private:
    wchar_t a[MaxSize];                  //字符数组
    int b[MaxSize];                       //权值数组
    wchar_t c[MaxSize][MaxSize];             //编码数组(每一行都是一段哈夫曼编码)
    int size = 0;
public:
    void Creat(Elemtype st[]);                         //创建函数,并对数组进行处理
    void CreatTree();                     //对后两个结点先处理
    void HuffmanTree(Nodes q, int i);     //对其他结点进行处理
    void HufftoCode(Elemtype st[]);       //哈夫曼编码
    void CodetoHuff(Elemtype code[]);         //哈夫曼解码
    friend void On_btnOk_Click();
};
/*创建函数,并对数组进行处理*/
void Huffman::Creat(Elemtype st[])
{
    Elemtype aCopy[MaxSize];//我们自然要对最开始输入的字符串进行处理,先复制
    int bCopy[MaxSize];
    int i, j, k;
    Elemtype t;
    /*输入数组*/
    for (i = 0; i < MaxSize && st[i]; i++, size++)
    {
        a[i] = st[i];
    }
    a[i] = '\0';
    for (i = 0; i < size; i++)
    {
        b[i] = 1;
    }
    /*数组复制*/
    for (i = 0; i < size; i++)
    {
        aCopy[i] = a[i];
        bCopy[i] = b[i];
    }
    cout << "size:" << size << endl;
    aCopy[i] = '\0';
    int protosize = size;
    /*压缩数组*/
    for (i = 0; i < size; i++)
    {
        for (j = i - 1; j >= 0; j--)
        {
            if (a[i] == a[j])
            {
                for (k = i; k <= size; k++)
                {
                    a[k] = a[k + 1];
                }
                b[j] += 1;
                size -= 1;
                i -= 1;
                break;
            }
        }
    }
    /*数组排序*/
    for (i = 0; i < size; i++)
    {
        k = i;
        for (j = i + 1; j < size; j++)
        {
            if (b[j] > b[i])
            {
                int p;
                Elemtype o;
                p = b[i]; o = a[i];
                b[i] = b[j]; a[i] = a[j];
                b[j] = p; a[j] = o;
            }
        }
    }

    for (i = 0; i < size; i++)
    {
        wcout << a[i] << ' ' << b[i] << ' ' << endl;
    }
    /*调用造树函数*/
    CreatTree();
    /*调用编码函数*/
    HufftoCode(aCopy);
}
/*造树，并优先处理最后两个结点*/
void Huffman::CreatTree()
{
    if (size >= 3)
    {
        Nodes o, p, q;
        o = new Node;
        p = new Node;
        q = new Node;
        p->data = a[size - 2];
        q->data = a[size - 1];
        p->weight = b[size - 2];
        q->weight = b[size - 1];

        c[size - 2][0] = '0';
        c[size - 2][1] = '\0';
        c[size - 1][0] = '1';
        c[size - 1][1] = '\0';

        p->LeftChild = NULL;
        q->LeftChild = NULL;
        p->RightChild = NULL;
        q->RightChild = NULL;

        o->data = NULL;
        o->weight = p->weight + q->weight;
        o->LeftChild = p;
        o->RightChild = q;

        HuffmanTree(o, size - 3);
    }
    else
    {
        MessageBox(NULL, L"好少", L"好少", MB_OK);
    }
}
/*造树，处理其他结点*/
void Huffman::HuffmanTree(Nodes q, int i)
{
    Nodes o, p;
    o = new Node;
    p = new Node;
    if (i >= 0)
    {
        p->data = a[i];
        p->weight = b[i];
        p->LeftChild = NULL;
        p->RightChild = NULL;

        c[i][0] = '0';
        c[i][1] = '\0';

        o->data = NULL;
        o->weight = p->weight + q->weight;
        o->LeftChild = p;
        o->RightChild = q;


        for (int x = i + 1; x < size; x++)
        {
            int row = 0;
            while (c[x][row] != '\0')
            {
                row++;
            }
            for (; row >= 0; row--)
            {
                c[x][row + 1] = c[x][row];
            }
            c[x][0] = '1';
        }
        HuffmanTree(o, i - 1);
    }
}
/*编码*/
void Huffman::HufftoCode(Elemtype st[])
{
    int i, j, k, back = 0;
    Elemtype b[MaxSize * MaxSize];
    for (i = 0; st[i]; i++)
    {
        for (j = 0; j < size; j++)
        {
            if (st[i] == a[j])
            {
                for (k = 0; c[j][k] != '\0'; k++)
                {
                    b[back++] = c[j][k];
                }
                break;
            }
        }
        if (j >= size)
        {
            b[back++] = '?';
        }
    }
    b[back] = '\0';
    MessageBox(NULL, b, wcscat(st, L"转换过后的结果是"), MB_OK);
    for (i = 0; i < back; i++)
    {
        wcout << b[i];
    }
}
/*解码*/
void Huffman::CodetoHuff(Elemtype code[])
{
    int start = 0, pos, i, j, x = 0, count = 0;
    Elemtype transed[MaxSize];
    for (; code[x] != '\0';)
    {
        pos = x;
        for (i = 0; i < size; i++)
        {
            for (j = 0; c[i][j] != '\0'; )
            {
                if (c[i][j] == code[pos])
                {
                    pos++;
                    j++;
                }
                else
                {
                    pos = x;
                    break;
                }
            }
            if (c[i][j] == '\0')
            {
                x = pos;
                transed[count++] = a[i];
                break;
            }
        }
        if (i >= size)
        {
            x = pos + 1;
        }
    }
    transed[count] = '\0';
    MessageBox(NULL, transed, wcscat(code, L"转换过后的结果是"), MB_OK);
    for (i = 0; i < count; i++)
    {
        wcout << transed[i];
    }
}
Huffman s;
// 实现文本框控件
class EasyTextBox
{
private:
    int left = 0, top = 0, right = 0, bottom = 0;	// 控件坐标
    wchar_t* text = NULL;							// 控件内容
    size_t maxlen = 0;									// 文本框最大内容长度

public:
    void Create(int x1, int y1, int x2, int y2, int max)
    {
        maxlen = max;
        text = new wchar_t[maxlen];
        text[0] = 0;
        left = x1, top = y1, right = x2, bottom = y2;

        // 绘制用户界面
        Show();
    }

    ~EasyTextBox()
    {
        if (text != NULL)
            delete[] text;
    }

    wchar_t* Text()
    {
        return text;
    }

    bool Check(int x, int y)
    {
        return (left <= x && x <= right && top <= y && y <= bottom);
    }

    // 绘制界面
    void Show()
    {
        // 备份环境值
        int oldlinecolor = getlinecolor();
        int oldbkcolor = getbkcolor();
        int oldfillcolor = getfillcolor();

        setlinecolor(LIGHTGRAY);		// 设置画线颜色
        setbkcolor(0xeeeeee);			// 设置背景颜色
        setfillcolor(0xeeeeee);			// 设置填充颜色
        fillrectangle(left, top, right, bottom);
        outtextxy(left + 10, top + 5, text);

        // 恢复环境值
        setlinecolor(oldlinecolor);
        setbkcolor(oldbkcolor);
        setfillcolor(oldfillcolor);
    }

    void OnMessage()
    {
        // 备份环境值
        int oldlinecolor = getlinecolor();
        int oldbkcolor = getbkcolor();
        int oldfillcolor = getfillcolor();

        setlinecolor(BLACK);			// 设置画线颜色
        setbkcolor(WHITE);				// 设置背景颜色
        setfillcolor(WHITE);			// 设置填充颜色
        fillrectangle(left, top, right, bottom);
        outtextxy(left + 10, top + 5, text);

        int width = textwidth(text);	// 字符串总宽度
        int counter = 0;				// 光标闪烁计数器
        bool binput = true;				// 是否输入中

        ExMessage msg;
        while (binput)
        {
            while (binput && peekmessage(&msg, EX_MOUSE | EX_CHAR, false))	// 获取消息，但不从消息队列拿出
            {
                if (msg.message == WM_LBUTTONDOWN)
                {
                    // 如果鼠标点击文本框外面，结束文本输入
                    if (msg.x < left || msg.x > right || msg.y < top || msg.y > bottom)
                    {
                        binput = false;
                        break;
                    }
                }
                else if (msg.message == WM_CHAR)
                {
                    size_t len = wcslen(text);
                    switch (msg.ch)
                    {
                    case '\b':				// 用户按退格键，删掉一个字符
                        if (len > 0)
                        {
                            text[len - 1] = 0;
                            width = textwidth(text);
                            counter = 0;
                            clearrectangle(left + 10 + width, top + 1, right - 1, bottom - 1);
                        }
                        break;
                    case '\r':				// 用户按回车键，结束文本输入
                    case '\n':
                        binput = false;
                        break;
                    default:				// 用户按其它键，接受文本输入
                        if (len < maxlen - 1)
                        {
                            text[len++] = msg.ch;
                            text[len] = 0;

                            clearrectangle(left + 10 + width + 1, top + 3, left + 10 + width + 1, bottom - 3);	// 清除画的光标
                            width = textwidth(text);				// 重新计算文本框宽度
                            counter = 0;
                            outtextxy(left + 10, top + 5, text);		// 输出新的字符串
                        }
                    }
                }
                char* m_char;
                int clen = WideCharToMultiByte(CP_ACP, 0, text, wcslen(text), NULL, 0, NULL, NULL);
                m_char = new char[clen + 1];
                WideCharToMultiByte(CP_ACP, 0, text, wcslen(text), m_char, clen, NULL, NULL);
                m_char[clen] = '\0';
                peekmessage(NULL, EX_MOUSE | EX_CHAR);				// 从消息队列抛弃刚刚处理过的一个消息
            }

            // 绘制光标（光标闪烁周期为 20ms * 32）
            counter = (counter + 1) % 32;
            if (counter < 16)
                line(left + 10 + width + 1, top + 3, left + 10 + width + 1, bottom - 3);				// 画光标
            else
                clearrectangle(left + 10 + width + 1, top + 3, left + 10 + width + 1, bottom - 3);		// 擦光标

            // 延时 20ms
            Sleep(20);
        }

        clearrectangle(left + 10 + width + 1, top + 3, left + 10 + width + 1, bottom - 3);	// 擦光标

        // 恢复环境值
        setlinecolor(oldlinecolor);
        setbkcolor(oldbkcolor);
        setfillcolor(oldfillcolor);

        Show();
    }
};
// 实现按钮控件
class EasyButton
{
private:
    int left = 0, top = 0, right = 0, bottom = 0;	// 控件坐标
    wchar_t* text = NULL;							// 控件内容
    void (*userfunc)() = NULL;						// 控件消息

public:
    void Create(int x1, int y1, int x2, int y2, const wchar_t* title, void (*func)())
    {
        text = new wchar_t[wcslen(title) + 1];
        wcscpy_s(text, wcslen(title) + 1, title);
        left = x1, top = y1, right = x2, bottom = y2;
        userfunc = func;

        // 绘制用户界面
        Show();
    }

    ~EasyButton()
    {
        if (text != NULL)
            delete[] text;
    }

    bool Check(int x, int y)
    {
        return (left <= x && x <= right && top <= y && y <= bottom);
    }

    // 绘制界面
    void Show()
    {
        int oldlinecolor = getlinecolor();
        int oldbkcolor = getbkcolor();
        int oldfillcolor = getfillcolor();

        setlinecolor(BLACK);			// 设置画线颜色
        setbkcolor(WHITE);				// 设置背景颜色
        setfillcolor(WHITE);			// 设置填充颜色
        fillrectangle(left, top, right, bottom);
        outtextxy(left + (right - left - textwidth(text) + 1) / 2, top + (bottom - top - textheight(text) + 1) / 2, text);

        setlinecolor(oldlinecolor);
        setbkcolor(oldbkcolor);
        setfillcolor(oldfillcolor);
    }

    void OnMessage()
    {
        if (userfunc != NULL)
            userfunc();
    }
};
// 定义控件
EasyTextBox txtName;
EasyTextBox txtPwd;
EasyButton btnOK;



// 按钮 btnOK 的点击事件
void On_btnOk_Click()
{   
    if (wcscmp(L"123", txtPwd.Text()))
    {
        MessageBox(GetHWnd(), L"密码错误", L"错误", MB_OK);
    }
        
    else
    {
        wchar_t s[100] = L"Hello, ";
        //wcscat_s(s, 100, txtName.Text());
        MessageBox(GetHWnd(), s, L"Hello", MB_OK);
    }
}
int main()
{
    
    initgraph(640, 480, 0);
    cleardevice();
    setbkcolor(0xeeeeee);
    cleardevice();
    settextcolor(BLACK);
    Elemtype st[10];
    InputBox(st, 100, L"请输入字符串", L"提示信息", NULL, 50, 105, FALSE);
    s.Creat(st);

    while (1)
    {
        if (MouseHit())
        {
            cleardevice();
            setbkcolor(0xeeeeee);
            cleardevice();
            settextcolor(BLACK);
            outtextxy(0, 0, L"左击输入字符并转换成编码");
            outtextxy(0, 20, L"右击输入字符并转换成编码");
            MOUSEMSG msg = GetMouseMsg();
            switch (msg.uMsg)
            {
            case WM_LBUTTONDOWN:
                Elemtype st[10];
                InputBox(st, 100, L"请输入字符串", L"提示信息", NULL, 50, 105, FALSE);
                s.HufftoCode(st);
                break;
            case WM_RBUTTONDOWN:
                Elemtype ch[MaxSize];
                InputBox(ch, 100, L"请输入字符串", L"提示信息", NULL, 50, 105, FALSE);
                s.CodetoHuff(ch);
            }
        }
    }
    getchar();
    closegraph();
}
